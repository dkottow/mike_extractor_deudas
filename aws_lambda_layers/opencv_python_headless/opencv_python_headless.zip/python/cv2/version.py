opencv_version = "4.5.1.48"
contrib = False
headless = True
ci_build = True