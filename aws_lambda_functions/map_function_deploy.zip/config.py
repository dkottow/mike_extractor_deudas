class Config:
    S3_BUCKET = "textract-console-us-east-2-7e1edcda-ec50-4013-9762-a06e7b200006"
    MODEL_PATH = "./forum.model"
    LAMBDA_REDUCE_FUNCTION = "Mike_OCR_Reduce"