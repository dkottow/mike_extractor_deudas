class Config:
    MODEL_PATH = "./forum.model"