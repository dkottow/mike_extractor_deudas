import pytest
from lambda_function import lambda_handler


def test_classification_with_CAV():

    event = {
        "version": "1.0",
        "timestamp": "2021-01-20T22:00:58.720Z",
        "requestContext": {
            "requestId": "3d6dbba0-ed17-48cc-ab81-1a1ecf0c298b",
            "functionArn": "arn:aws:lambda:us-east-2:454177333545:function:Mike_OCR_PDF_To_Descriptor:$LATEST",
            "condition": "Success",
            "approximateInvokeCount": 1,
        },
        "requestPayload": {
            "Records": [
                {
                    "eventVersion": "2.1",
                    "eventSource": "aws:s3",
                    "awsRegion": "us-east-2",
                    "eventTime": "2021-01-20T22:00:50.452Z",
                    "eventName": "ObjectCreated:Put",
                    "userIdentity": {"principalId": "AWS:AROAWTPYUEEUQM3LJFI6F:Mike_OCR_Map"},
                    "requestParameters": {"sourceIPAddress": "3.140.199.2"},
                    "responseElements": {
                        "x-amz-request-id": "01BDDA64A6566AB6",
                        "x-amz-id-2": "rn+rY2kH6sJb4VuIpiBqsaNb/pezRnzTGwekX2ZzEy5ydryeQV9tQd1xwFRBf88PFMvZXwR1DpJCmHrK2y6yBR4ETGTO/P35",
                    },
                    "s3": {
                        "s3SchemaVersion": "1.0",
                        "configurationId": "4cdd5e97-9790-4cb6-bb9c-fa4648ad18cf",
                        "bucket": {
                            "name": "textract-console-us-east-2-7e1edcda-ec50-4013-9762-a06e7b200006",
                            "ownerIdentity": {"principalId": "AFTBJ9N16F5MT"},
                            "arn": "arn:aws:s3:::textract-console-us-east-2-7e1edcda-ec50-4013-9762-a06e7b200006",
                        },
                        "object": {
                            "key": "ExtractorDeudas/Archivo/Forum/2021-01-20T22_00_52_875730/CAMILA_SEGUEL_-_CAV.pdf",
                            "size": 47395,
                            "eTag": "3cc458c4c5ba498b93005268ef061cac",
                            "sequencer": "006008A8174A4310A0",
                        },
                    },
                }
            ]
        },
        "responseContext": {"statusCode": 200, "executedVersion": "$LATEST"},
        "responsePayload": {
            "key": "ExtractorDeudas/Archivo/Forum/2021-01-11T20_03_11_360740/CAMILA SEGUEL - CAV.pdf",
            "descriptor": [
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                76557614.91287231,
                20828057.775706768,
                17019702.346832275,
                21009693.29958296,
                53551199.23613644,
                15483005.060612679,
                19822567.47510135,
                24202483.17569208,
                81467944.18061256,
                18662252.436222196,
                16806243.660517693,
                19548159.238996506,
                53400117.653422356,
                17781751.876443386,
                21410422.010733724,
                24187568.366863728,
            ],
            "descriptor_type": "HOG",
        },
    }

    expected_output = {
        "key": "ExtractorDeudas/Archivo/Forum/2021-01-11T20_03_11_360740/CAMILA SEGUEL - CAV.pdf",
        "document_type": "cav",
    }
    assert lambda_handler(event, "") == expected_output


def test_exception():
    event = {
        "responsePayload": {
            "descriptor": [
                0.0,
                0.0,
            ],
            "descriptor_type": "HOG",
            "key": "ExtractorDeudas/Archivo/Forum/2021-01-11T20_03_11_360740/CAMILA SEGUEL - CAV.pdf",
        }
    }
    with pytest.raises(Exception, match=r".*Unexpected exception in document classifier.*"):
        lambda_handler(event, "")


if __name__ == "__main__":
    test_classification_with_CAV()
    test_exception()
    print("\033[92mAll test OK\033[0m")
