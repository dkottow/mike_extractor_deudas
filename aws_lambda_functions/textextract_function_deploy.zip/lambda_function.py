import io
import json
import logging

import boto3
import pandas as pd

from config import Config as config
from utils import parse_mike_key, parsed_mike_key_to_str
from forum_pipeline import ForumDocumentPipeline

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event: dict, context):

    key = event.get("key", None)
    parsed_key = parse_mike_key(key)

    descriptor = event.get("descriptor", None)

    logger.info(f"Classifing {key} document type")
    s3_client = boto3.client("s3")

    try:

        if parsed_key["extension"] == "pdf":

            pipeline = ForumDocumentPipeline(key, descriptor)
            results = pipeline.execute_detection()

            data: pd.DataFrame = results["data"]
            csv_buffer = io.StringIO()
            data.to_csv(csv_buffer)

            csv_key = parsed_mike_key_to_str(parsed_key, new_bandeja="Salida", new_extension=".csv")
            s3_client.upload_fileobj(io.BytesIO(csv_buffer.getvalue()), Bucket=config.S3_BUCKET, Key=csv_key)

            return results

        else:
            msg = f"Error while trying to process {key}: is not a pdf file."
            s3_client.upload_fileobj(
                io.BytesIO(json.dumps({"success": False, "error": msg}).encode()),
                Bucket=config.S3_BUCKET,
                Key=parsed_mike_key_to_str(parsed_key, new_bandeja="Errores", new_extension=".json"),
            )
            logger.error(msg)
            return {"success": False, "error": msg}

    except Exception as e:
        msg = f"[{key}] Unexpected exception: {e}"
        s3_client.upload_fileobj(
            io.BytesIO(json.dumps({"success": False, "error": msg}).encode()),
            Bucket=config.S3_BUCKET,
            Key=parsed_mike_key_to_str(parsed_key, new_bandeja="Errores", new_extension=".json"),
        )
        return {"success": False, "error": msg}


if config.MODE == "DEV" and __name__ == "__main__":

    lambda_handler(config.EVENT_EXAMPLE, {})
