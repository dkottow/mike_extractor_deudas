"""
Contiene el Pipeline para ejecutar OCR a cualquier archivo de Forum.

Consta de los siguientes pasos:

1. Clasificar el tipo de archivo
2. Analizar el archivo usando TextExtract
3. Procesa los resultados y retornar.
"""
import logging
from typing import Dict, Union

import numpy as np
import pandas as pd
from joblib import load

from textextract_adapter import TextExtractClientAdapter, ProcessType
from forum.desarolllo_contratos import DesarrolloContratosProcessor
from forum.cav import CAVProcessor
from forum.pagare import PagareProcessor
from config import Config as config
from processor import Processor
from utils import parse_mike_key

logger = logging.getLogger()
logger.setLevel(logging.INFO)


FORUM_PROCESSORS = {"cav": CAVProcessor, "pagare": PagareProcessor, "tabla": DesarrolloContratosProcessor}

FORUM_PROCESS_TYPE_BY_FILE_CLASS = {
    "cav": ProcessType.DETECTION,
    "pagare": ProcessType.DETECTION,
    "tabla": ProcessType.ANALYSIS,
}


class ForumDocumentPipeline:
    def __init__(self, key: str, descriptor: list) -> None:
        self.key = key
        self.parsed_key = parse_mike_key(key)
        self.clf = load(config.MODEL_PATH)
        self.descriptor = descriptor

    def analyze_with_textextract(self, key: str, process_type: int, parse_results: bool = True) -> Dict:

        textextract_adapter = TextExtractClientAdapter(key, process_type)
        textextract_adapter.CreateTopicandQueue()

        # Esperar a que textextract termine de procesar el documento
        textextract_adapter.ProcessDocument()

        # Limpiar y retornar
        textextract_adapter.DeleteTopicandQueue()
        results = textextract_adapter.GetResults(parsed=parse_results)
        return results

    def execute_detection(self) -> Dict[str, Union[str, pd.DataFrame]]:
        try:
            logging.info(f"[{self.key}] - Detection process started. Classifying document.")

            # --------------------------------------------------------------------------
            # 1. Clasificar y escoger el tipo de procesador y tipo de analisis que Textextract ejecutará

            self.document_type: str = self.clf.predict(np.array([self.descriptor]))[0]

            self.processor = FORUM_PROCESSORS[self.document_type]()
            self.process_type = FORUM_PROCESS_TYPE_BY_FILE_CLASS[self.document_type]

            logger.info(
                f"[{self.key}] - Processor choosed: {self.processor}. TextExtract process_type: {self.process_type}"
            )

            # --------------------------------------------------------------------------
            # 2. Analizar el archivo en textextract

            logger.info(f"[{self.key}] - TextExtract analysis started")

            self.textextract_response = self.analyze_with_textextract(self.key, self.process_type)

            logger.info(
                f"[{self.key}] - Detection Ended. Found {len(self.textextract_response['text'].split(' '))} words "
                f"aprox. and {len(self.textextract_response['tables'])} tables"
            )

            # --------------------------------------------------------------------------
            # 3. Procesar la resultas con los procesadores y retornar

            logger.info(f"[{self.key}] - Processing results")

            self.processed_results = self.processor.process_response(self.textextract_response, self.parsed_key)

            logger.info(f"[{self.key}] - Results processed. Returning...")

            return {"key": self.key, "document_type": self.document_type, "data": self.processed_results}

        except Exception as e:
            msg = f"[{self.key}] An exception has occurred while trying to process the document: {e}"
            logger.exception(msg)
            return {"key": self.key, "error": msg}

    def _execute_again_processor(self, return_dict=False):
        # Método solo para debugear
        try:
            # Analizar respuesta y retornar
            logger.info(f"[{self.key}] - Processing results")

            self.processed_results = self.processor.process_response(self.textextract_response, self.parsed_key)

            logger.info(f"[{self.key}] - Results processed. Returning...")

            if return_dict:
                return self.processed_results

            return {"filename": self.filename, "document_type": self.document_type, "data": self.processed_results}

        except Exception as e:
            print(f"[{self.key}]No se ha ejecutado aún . Error: {e}")
